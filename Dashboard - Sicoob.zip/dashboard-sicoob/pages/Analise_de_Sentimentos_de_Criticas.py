import streamlit as st
from textblob import TextBlob
from googletrans import Translator
import pandas as pd
import matplotlib.pyplot as plt

# Tradução da entrada para inglês e posterior análise de sentimento usando a biblioteca TextBlob
def analisar_sentimento(critica):
    translator = Translator()
    traducao = translator.translate(critica, src='auto', dest='en')
    sentimento = TextBlob(traducao.text).sentiment.polarity
    if sentimento > 0:
        return 'Positivo'
    elif sentimento < 0:
        return 'Negativo'
    else:
        return 'Neutro'

# Banco de críticas
críticas = [
    "Este lugar é incrível! Eu amei cada momento.",
    "A vista era espetacular, mas o serviço foi péssimo.",
    "Nada demais, não gostei da comida.",
    "Fui com baixas expectativas, mas me surpreendi positivamente.",
    "Lugar horrível, sujo, atendimento precário. Nunca mais voltaria. Péssimo."
]

# DataFrame com os sentimentos
data = {'Crítica': críticas}
df = pd.DataFrame(data)
df['Sentimento'] = df['Crítica'].apply(analisar_sentimento)

# Gáfico de barras

st.subheader('Incidência de sentimentos registrados')
st.bar_chart(df['Sentimento'].value_counts())



# DataFrame atualizado
st.write(df)
