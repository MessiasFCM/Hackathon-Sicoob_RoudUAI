import matplotlib.pyplot as plt
import streamlit as st
import pandas as pd
import seaborn as sns

pto_tur2 = pd.read_csv("ptoreal.csv", encoding='iso-8859-1')
turista = pd.read_csv("turista.csv", encoding='iso-8859-1')

# Plota boxplot e desvio padrão das variáveis quantitativas

st.subheader('Boxplot e desvio padrão da idade dos turistas')
fig = plt.figure(figsize=(16, 8))
sns.boxplot(x='idade', data=turista)
st.pyplot(fig)
idade_std = turista['idade'].std()
st.write('O desvio padrão da idade dos turistas é de',idade_std)


st.subheader('Boxplot e desvio padrão do número de viagens trilhadas pelos usuários na plataforma')
fig = plt.figure(figsize=(16, 8))
sns.boxplot(x='viagens-pela-plataforma', data=turista)
st.pyplot(fig)
turista_std = turista['viagens-pela-plataforma'].std()
st.write('O desvio padrão das viagens realizadas previamente pelos turistas na plataforma é de',turista_std)



st.subheader('Boxplot e desvio padrão das avaliações dos pontos turísticos')
fig = plt.figure(figsize=(16, 8))
sns.boxplot(x='avaliacao', data=pto_tur2)
st.pyplot(fig)
avaliacao_std = pto_tur2['avaliacao'].std()
st.write('O desvio padrão das avaliacoes dos estabelecimentos pelos turistas é de',turista_std)



