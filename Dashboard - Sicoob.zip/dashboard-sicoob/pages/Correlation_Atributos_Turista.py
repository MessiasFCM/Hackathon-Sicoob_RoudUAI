import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

turista = pd.read_csv('turista.csv')
turista = pd.DataFrame(turista)

# Mapa de calor dos atributos dos turistas
st.subheader('Correlação entre os atributos dos turistas')
fig, ax = plt.subplots()
sns.heatmap(turista.corr(), ax=ax)
st.write(fig)