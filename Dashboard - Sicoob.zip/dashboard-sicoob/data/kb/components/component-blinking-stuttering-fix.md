---
title: My Component seems to be blinking/stuttering...how do I fix that?
slug: /knowledge-base/components/component-blinking-stuttering-fix
---

# My Component seems to be blinking/stuttering...how do I fix that?

Currently, no automatic debouncing of Component updates is performed within Streamlit. The Component creator themselves can decide to rate-limit the updates they send back to Streamlit.
