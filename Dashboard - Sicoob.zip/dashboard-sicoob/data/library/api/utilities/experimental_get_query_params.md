---
title: st.experimental_get_query_params
slug: /library/api-reference/utilities/st.experimental_get_query_params
description: st.experimental_get_query_params returns query parameters currently showing in the browser's URL bar.
---

<Important>

This is an experimental feature. Experimental features and their APIs may change or be removed at any time. To learn more, click [here](/library/advanced-features/prerelease#experimental-features).

</Important>

<Autofunction function="streamlit.experimental_get_query_params" />
