---
title: st.set_page_config
slug: /library/api-reference/utilities/st.set_page_config
description: st.set_page_config configures the default settings of the page.
---

<Autofunction function="streamlit.set_page_config" />
