---
title: st.title
slug: /library/api-reference/text/st.title
description: st.title displays text in title formatting.
---

<Autofunction function="streamlit.title" />

<Image src="/images/api/st.title.png" clean />
