---
title: st.graphviz_chart
slug: /library/api-reference/charts/st.graphviz_chart
description: st.graphviz_chart displays a graph using the dagre-d3 library.
---

<Autofunction function="streamlit.graphviz_chart" />
