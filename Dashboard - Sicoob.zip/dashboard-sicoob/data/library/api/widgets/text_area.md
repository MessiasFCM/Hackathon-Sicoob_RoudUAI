---
title: st.text_area
slug: /library/api-reference/widgets/st.text_area
description: st.text_area displays a multi-line text input widget.
---

<Autofunction function="streamlit.text_area" />
