---
title: st.color_picker
slug: /library/api-reference/widgets/st.color_picker
description: st.color_picker displays a color picker widget.
---

<Autofunction function="streamlit.color_picker" />
