---
title: st.multiselect
slug: /library/api-reference/widgets/st.multiselect
description: st.multiselect displays a multiselect widget. The multiselect widget starts as empty.
---

<Autofunction function="streamlit.multiselect" />
