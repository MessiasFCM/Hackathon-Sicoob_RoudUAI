---
title: st.tabs
slug: /library/api-reference/layout/st.tabs
description: st.tabs inserts containers separated into tabs.
---

<Autofunction function="streamlit.tabs" />
