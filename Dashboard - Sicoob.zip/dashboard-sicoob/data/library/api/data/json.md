---
title: st.json
slug: /library/api-reference/data/st.json
description: st.json displays object or string as a pretty-printed JSON string.
---

<Autofunction function="streamlit.json" />
