---
title: st.column_config.TextColumn
slug: /library/api-reference/data/st.column_config/st.column_config.textcolumn
---

<Autofunction function="streamlit.column_config.TextColumn" />
