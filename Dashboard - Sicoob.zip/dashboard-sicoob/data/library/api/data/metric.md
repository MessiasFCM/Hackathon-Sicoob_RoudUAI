---
title: st.metric
slug: /library/api-reference/data/st.metric
description: st.metric displays a metric in big bold font, with an optional indicator of how the metric changed.
---

<Autofunction function="streamlit.metric" />
