---
title: st.experimental_rerun
slug: /library/api-reference/control-flow/st.experimental_rerun
description: st.experimental_rerun will rerun the script immediately.
---

<Important>

This is an experimental feature. Experimental features and their APIs may change or be removed at any time. To learn more, click [here](/library/advanced-features/prerelease#experimental-features).

</Important>

<Autofunction function="streamlit.experimental_rerun" />
